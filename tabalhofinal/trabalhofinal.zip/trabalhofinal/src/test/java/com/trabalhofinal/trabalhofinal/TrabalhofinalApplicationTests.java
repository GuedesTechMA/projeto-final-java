package com.trabalhofinal.trabalhofinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabalhofinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
